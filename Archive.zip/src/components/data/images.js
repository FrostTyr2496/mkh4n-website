// src/data/images.js

const images = [
    {
      id: 1,
      alt: '2021-09-24_IMG_1545',
      thumbnail: require('../assets/images/thumbs/2021-09-24_IMG_1545.jpg'),
      medium: require('../assets/images/medium/2021-09-24_IMG_1545.jpg'),
      full: require('../assets/images/full/2021-09-24_IMG_1545.jpg'),
    }
  ];
  
export default images;