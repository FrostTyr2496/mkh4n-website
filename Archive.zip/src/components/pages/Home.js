import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to mkh4n.com</h1>
      <p>This is the currently horribly broken home page.</p>
      <p>Don't bother trying to open the links in the navbar.</p>
      <p>There will eventually be some nice looking content here (hopefully).</p>
    </div>
  );
}

export default Home;